How to setup:

1. Have 'numpy' and 'matplotlib' libararies installed in your enviornment

2. Have the following folder structure:
some_folder/
	ex3.jar - Compiled jar which uses the assignment supplied Main.main as the entrypoint
	plotRuntime.py
	file_inputs/
		mainTable.txt - 50,000 row table with id as primary key
		foreignTable5mil.txt - 5,000,000 row table where column 1 is a foreign key (not unique)
		foreignTable10mil.txt - same as above
		foreignTable15mil.txt - same as above
		foreignTable20mil.txt - same as above
	temp/ - folder where temp files will be created. Must already exist.

3. Choose your substrings for select (top of file, under "# MAGIC NUMBERS")

4. Run the python file and wait. Graph pictures will be created in the end.

-- Notes

-To create the foreign table files, the assignment supplied FileGenerator.jar creates such files for the second file.
So for example:
java -jar FileGenerator.jar mainTable.txt 50000 foreignTable5mil.txt 5000000

-To compile ex3.jar, go to file->project structure->artifacts tab
Click the plus sign, choose JAR -> from module with dependancies, and choose Main.main as entrypoint.
If you have trouble, maybe try compiling manually (google)