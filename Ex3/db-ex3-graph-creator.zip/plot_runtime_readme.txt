How to setup:

1. Have 'numpy' and 'matplotlib' libararies installed in your enviornment

2. Have the following folder structure:
some_folder/
	plotRuntime.py
	file_inputs/
		mainTable.txt - 50,000 row table with id as primary key
		foreignTable5mil.txt - 5,000,000 row table where column 1 is a foreign key (not unique)
		foreignTable10mil.txt - same as above
		foreignTable15mil.txt - same as above
		foreignTable20mil.txt - same as above
	temp/ - folder where temp files will be created. Must already exist.

3. Choose your substrings for select (top of file, under "# MAGIC NUMBERS")

4. Run the python file and wait. Graph pictures will be created in the end.