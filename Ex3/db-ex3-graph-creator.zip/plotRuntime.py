import subprocess
import time
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

# MAGIC NUMBERS
SELECT_CHAR_LENGTH_1 = "Your length 1 selector here"
SELECT_CHAR_LENGTH_3 = "Your length 3 selector here"
SELECT_CHAR_LENGTH_5 = "Your length 5 selector here"


TABLE_NAME = LEGEND_NAME = CONDITION_LENGTH = 0
NUM_ROWS_FIELD = EXEC_TYPE = SUBSTRING_TO_USE = 1

# Files to use
OUTPUT = "output.txt"
TEMP_PATH = "temp"

# Initializations, constants
mainTable = "file_inputs/mainTable.txt"
foreignTables = [("file_inputs/foreignTable5mil.txt", 5000000),
                 ("file_inputs/foreignTable10mil.txt", 10000000),
                 ("file_inputs/foreignTable15mil.txt", 15000000),
                 ("file_inputs/foreignTable20mil.txt", 20000000)
                 ]

# Separate conditions to test
conditions = [
    (1, SELECT_CHAR_LENGTH_1),
    (3, SELECT_CHAR_LENGTH_3),
    (5, SELECT_CHAR_LENGTH_5)
]

# Plot labels
PLOT_TITLE = "Join with select, condition length {}"
PLOT_X_AXIS_TITLE = "Number of rows in second file (foreign key table)"
PLOT_Y_AXIS_TITLE = "Time (seconds)"
PLOT_LEGEND = [("Select pre join", "D"),
               ("Naive", "C")]

COLORS = {
    "Naive": "red",
    "Select pre join": "blue"
}


def timeit(method):
    def timed(*args, **kw):
        ts = time.time()
        method(*args, **kw)
        te = time.time()
        return int(te - ts)

    return timed


def run_jar(options):
    subprocess.call(['java', '-jar', 'ex3.jar', *options])


def all_tests():
    results = []
    for test_condition in conditions:
        condition_results = []
        for legend in PLOT_LEGEND:
            plot_res = []
            for foreign_table in foreignTables:
                plot_res.append((foreign_table[NUM_ROWS_FIELD],
                                 timeit(run_jar)([legend[EXEC_TYPE],
                                                  mainTable,
                                                  foreign_table[TABLE_NAME],
                                                  OUTPUT,
                                                  test_condition[SUBSTRING_TO_USE],
                                                  TEMP_PATH])
                                 ))
            print(plot_res)
            condition_results.append((legend[LEGEND_NAME], plot_res))
        results.append((test_condition[CONDITION_LENGTH], condition_results))
    return results


def create_results_graph_image(results):
    for condition_length, condition_results in results:
        '''
        Initialize new plot
        '''
        plt.close()
        fig = plt.figure(figsize=(10, 8))
        plt.title(PLOT_TITLE.format(condition_length))
        plt.xlabel(PLOT_X_AXIS_TITLE)
        plt.ylabel(PLOT_Y_AXIS_TITLE)
        # set x and y axis ranges
        plt.axis([0, 25000000, 0, 250])
        # change y axis jumps
        plt.yticks(np.arange(0, 250, 20))
        # display numbers, not scientific 1e7
        plt.ticklabel_format(style='plain')
        # comma-separated numbers on axis
        ax = plt.gca()
        ax.get_xaxis().set_major_formatter(
            matplotlib.ticker.FuncFormatter(lambda x, p: format(int(x), ',')))

        # Add all dots / scatter all data points
        for legend_name, plot_res in condition_results:
            plt.scatter([num_rows for num_rows, runtime in plot_res], [runtime for num_rows, runtime in plot_res], color=COLORS[legend_name], label=legend_name)
        # pop out the legend and save the file
        plt.legend()
        plt.savefig('plot{}.png'.format(condition_length))


if __name__ == '__main__':
    res = [
        (1, [(
            "Naive",
            [(5000000, 50)]
        ),
            (
                "Select pre join",
                [(5000000, 25)]
            )
        ]),
        (3, [(
            "Naive",
            [(10000000, 50)]
        )])
    ]
    create_results_graph_image(all_tests())
